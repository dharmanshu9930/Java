/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    float a,b,c,d,e;
    cout<<"ENTER YOUR MARKS IN  ENGLISH :";
    cin>>a;
    cout<<"ENTER YOUR MARKS IN PHYSICS :";
    cin>>b;
    cout<<"ENTER YOUR MARKS IN CHEMISTRY :";
    cin>>c;
    cout<<"ENTER YOUR MARKS IN  MATHS :";
    cin>>d;
    cout<<"ENTER YOUR MARKS IN COMPUTER :";
    cin>>e;
    
    if(a,b,c,d,e >= 35 && (a+b+c+d+e)/5 >=40)
    {cout<<"pass";}
    
    else 
    {cout<<"fail";}
    return 0;
}